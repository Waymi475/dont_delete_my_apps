package com.dontdeletemyapps

import android.content.Context
import java.security.MessageDigest

object GuardPrefs {
    private const val PREFS = "guard_settings"
    private const val KEY_PIN_HASH = "pin_hash"
    private const val KEY_PROTECTED = "protected_packages"

    fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun setPin(context: Context, pin: String) {
        prefs(context).edit().putString(KEY_PIN_HASH, sha256(pin)).apply()
    }
    fun hasPin(context: Context) = !prefs(context).getString(KEY_PIN_HASH, null).isNullOrBlank()
    fun checkPin(context: Context, pin: String) = prefs(context).getString(KEY_PIN_HASH, null) == sha256(pin)
    fun protectedPackages(context: Context): MutableSet<String> =
        prefs(context).getStringSet(KEY_PROTECTED, emptySet())?.toMutableSet() ?: mutableSetOf()
    fun setProtected(context: Context, packageName: String, enabled: Boolean) {
        val set = protectedPackages(context)
        if (enabled) set.add(packageName) else set.remove(packageName)
        prefs(context).edit().putStringSet(KEY_PROTECTED, set).apply()
    }
    fun setAllProtected(context: Context, packages: Collection<String>, enabled: Boolean) {
        val set = protectedPackages(context)
        if (enabled) set.addAll(packages) else set.removeAll(packages.toSet())
        prefs(context).edit().putStringSet(KEY_PROTECTED, set).apply()
    }
    private fun sha256(value: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(value.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
