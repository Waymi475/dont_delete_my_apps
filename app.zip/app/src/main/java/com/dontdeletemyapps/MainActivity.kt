package com.dontdeletemyapps

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.*

class MainActivity : Activity() {
    private data class AppItem(val name: String, val pkg: String)

    private val purple = Color.rgb(181, 83, 255)
    private val green = Color.rgb(0, 230, 135)
    private val panel = Color.rgb(18, 14, 25)

    private var apps: List<AppItem> = emptyList()
    private var protectedSet: MutableSet<String> = mutableSetOf()
    private var adapter: AppsAdapter? = null
    private var selectAllButton: Button? = null
    private var loadingLabel: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            buildScreen()
            loadApps()
        } catch (t: Throwable) {
            showError(t)
        }
    }

    override fun onResume() {
        super.onResume()
        // The guard service may have removed protection after a correct PIN.
        protectedSet = GuardPrefs.protectedPackages(this)
        adapter?.notifyDataSetChanged()
        updateSelectAll()
    }

    private fun showError(t: Throwable) {
        val text = TextView(this).apply {
            this.text = "Ошибка запуска:\n\n" + t.stackTraceToString()
            setTextColor(Color.WHITE); textSize = 12f; setPadding(dp(16), dp(40), dp(16), dp(16))
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.BLACK); addView(text) })
    }

    private fun buildScreen() {
        protectedSet = GuardPrefs.protectedPackages(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        // targetSdk 35 draws edge-to-edge: keep content clear of the system bars.
        root.setOnApplyWindowInsetsListener { v, insets ->
            val l: Int; val t: Int; val r: Int; val b: Int
            if (Build.VERSION.SDK_INT >= 30) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                l = bars.left; t = bars.top; r = bars.right; b = bars.bottom
            } else {
                @Suppress("DEPRECATION") run {
                    l = insets.systemWindowInsetLeft; t = insets.systemWindowInsetTop
                    r = insets.systemWindowInsetRight; b = insets.systemWindowInsetBottom
                }
            }
            v.setPadding(l, t, r, b)
            insets
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(8))
        }
        header.addView(TextView(this).apply {
            text = "Don't delete my apps"
            textSize = 25f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(6))
        })
        header.addView(label("Выбирай приложения, которые нельзя удалить без PIN-кода."))
        val status = label(if (GuardPrefs.hasPin(this)) "PIN-код настроен" else "Сначала установи PIN-код", green)
        header.addView(status)

        val pinInput = EditText(this).apply {
            hint = "Новый PIN (минимум 4 цифры)"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            inputType = 2
            setPadding(dp(14), 0, dp(14), 0)
            setBackgroundColor(panel)
        }
        header.addView(pinInput, params())
        header.addView(button("Сохранить PIN").apply {
            setOnClickListener {
                val pin = pinInput.text.toString()
                if (pin.length < 4 || pin.any { !it.isDigit() }) toast("Нужно минимум 4 цифры")
                else {
                    GuardPrefs.setPin(this@MainActivity, pin)
                    toast("PIN сохранён")
                    pinInput.text.clear()
                    status.text = "PIN-код настроен"
                }
            }
        }, params())

        header.addView(button("Включить службу специальных возможностей").apply {
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, params())
        header.addView(label("В настройках найди Don't delete my apps и включи службу."))
        header.addView(label("HyperOS: открой «О приложении» → включи «Автозапуск», «Экономия заряда» → «Нет ограничений», а в «Ещё» разреши ограниченные настройки. Закрепи приложение в недавних (замок)."))
        header.addView(button("Настройки этого приложения").apply {
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
        }, params())
        header.addView(label("Приложения для защиты", purple))

        selectAllButton = button("Выбрать все").apply {
            setOnClickListener {
                if (!GuardPrefs.hasPin(this@MainActivity)) { toast("Сначала установи PIN-код"); return@setOnClickListener }
                val all = allSelected()
                GuardPrefs.setAllProtected(this@MainActivity, apps.map { it.pkg }, !all)
                protectedSet = GuardPrefs.protectedPackages(this@MainActivity)
                adapter?.notifyDataSetChanged()
                updateSelectAll()
            }
        }
        header.addView(selectAllButton, params())
        loadingLabel = label("Загрузка списка приложений…")
        header.addView(loadingLabel)

        val list = ListView(this).apply {
            setBackgroundColor(Color.BLACK)
            divider = ColorDrawable(0xFF29222F.toInt())
            dividerHeight = dp(1)
            itemsCanFocus = true
            addHeaderView(header, null, false)
        }
        adapter = AppsAdapter()
        list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(-1, -1))
        setContentView(root)
        root.requestApplyInsets()
    }

    private fun loadApps() {
        Thread {
            val result = try {
                packageManager.getInstalledApplications(0)
                    .filter { it.packageName != packageName }
                    .map { AppItem(packageManager.getApplicationLabel(it).toString(), it.packageName) }
                    .sortedBy { it.name.lowercase() }
            } catch (_: Throwable) { emptyList() }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                apps = result
                loadingLabel?.visibility = View.GONE
                adapter?.notifyDataSetChanged()
                updateSelectAll()
            }
        }.start()
    }

    private fun allSelected() = apps.isNotEmpty() && apps.all { protectedSet.contains(it.pkg) }

    private fun updateSelectAll() {
        selectAllButton?.text = if (allSelected()) "Снять выбор со всех" else "Выбрать все"
    }

    private inner class AppsAdapter : BaseAdapter() {
        override fun getCount() = apps.size
        override fun getItem(position: Int) = apps[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val item = apps[position]
            val check = (convertView as? CheckBox) ?: CheckBox(this@MainActivity).apply {
                textSize = 14f
                setTextColor(Color.WHITE)
                buttonTintList = ColorStateList.valueOf(purple)
                setPadding(dp(22), dp(7), dp(18), dp(7))
            }
            check.setOnCheckedChangeListener(null)
            check.text = "${item.name}\n${item.pkg}"
            check.isChecked = protectedSet.contains(item.pkg)
            check.setOnCheckedChangeListener { buttonView, checked ->
                if (!GuardPrefs.hasPin(this@MainActivity)) {
                    toast("Сначала установи PIN-код")
                    buttonView.post { notifyDataSetChanged() }
                } else {
                    GuardPrefs.setProtected(this@MainActivity, item.pkg, checked)
                    if (checked) protectedSet.add(item.pkg) else protectedSet.remove(item.pkg)
                    updateSelectAll()
                }
            }
            return check
        }
    }

    private fun label(text: String, color: Int = Color.LTGRAY) = TextView(this).apply {
        this.text = text; textSize = 14f; setTextColor(color); setPadding(0, dp(10), 0, dp(8))
    }
    private fun button(text: String) = Button(this).apply {
        this.text = text; setTextColor(Color.WHITE); setBackgroundColor(0xFF6826A8.toInt()); isAllCaps = false
    }
    private fun params() = LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(8) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
