package com.dontdeletemyapps

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class UninstallGuardService : AccessibilityService() {
    private var promptShown = false
    private var overlay: android.view.View? = null

    private var lastDismiss = 0L
    private val allowedPackageParts = listOf(
        "installer", "launcher", "miui", "xiaomi", "settings", "vending", "appmanager", "securitycenter"
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || promptShown) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val source = event.packageName?.toString()?.lowercase() ?: return
        if (source == packageName || allowedPackageParts.none { source.contains(it) }) return
        // Only dialogs / the uninstall screen: the home screen, recents and normal app screens are ignored.
        val cls = event.className?.toString()?.lowercase() ?: return
        if (listOf("dialog", "uninstall", "alert").none { cls.contains(it) }) return
        if (android.os.SystemClock.uptimeMillis() - lastDismiss < 3000) return
        val protectedSet = GuardPrefs.protectedPackages(this)
        if (protectedSet.isEmpty()) return

        val texts = mutableListOf<String>()
        try {
            val root = rootInActiveWindow ?: return
            if (root.packageName?.toString()?.lowercase() != source) return
            collectText(root, texts)
        } catch (_: Exception) { return }
        // A confirmation dialog has only a few text nodes; a whole app list or settings page has many.
        if (texts.isEmpty() || texts.size > 20) return
        val lines = texts.map { it.lowercase().trim() }
        val combined = lines.joinToString(" ")
        val asksUninstall = listOf("uninstall", "удалить", "удаление", "деинсталл", "remove app").any { combined.contains(it) }
        val hasCancel = lines.any { it == "отмена" || it == "отменить" || it == "cancel" || it == "нет" }
        if (!asksUninstall || !hasCancel) return

        val pkg = findProtectedApp(combined, protectedSet) ?: return
        promptShown = true
        // Close the confirmation dialog, then ask for the PIN.
        performGlobalAction(GLOBAL_ACTION_BACK)
        showPinPrompt(pkg)
    }

    private fun collectText(node: AccessibilityNodeInfo?, out: MutableList<String>) {
        if (node == null || !node.isVisibleToUser) return
        node.text?.toString()?.let(out::add)
        node.contentDescription?.toString()?.let(out::add)
        for (i in 0 until node.childCount) collectText(node.getChild(i), out)
    }

    private val labelCache = HashMap<String, String>()

    private fun labelOf(pkg: String): String = labelCache.getOrPut(pkg) {
        try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString().lowercase()
        } catch (_: Exception) { "" }
    }

    private fun findProtectedApp(text: String, protected: Set<String>): String? {
        for (pkg in protected) {
            val label = labelOf(pkg)
            if (label.isNotBlank() && text.contains(label)) return pkg
        }
        return null
    }

    private fun showPinPrompt(pkg: String) {
        val name = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) { pkg }

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(20), dp(22), dp(18))
            setBackgroundColor(Color.rgb(15, 10, 22))
        }
        panel.addView(TextView(this).apply {
            text = "🛡  Don't delete my apps"
            textSize = 20f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(190, 110, 255))
        })
        panel.addView(TextView(this).apply {
            text = "\nЗащищено от удаления:\n$name\n\nВведи PIN, чтобы разрешить удаление. Затем повтори попытку."
            textSize = 15f; setTextColor(Color.WHITE)
        })
        val pin = EditText(this).apply {
            hint = "PIN-код"; inputType = 2; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        }
        panel.addView(pin)
        panel.addView(Button(this).apply {
            text = "Разрешить удаление"
            setOnClickListener {
                if (GuardPrefs.checkPin(this@UninstallGuardService, pin.text.toString())) {
                    GuardPrefs.setProtected(this@UninstallGuardService, pkg, false)
                    Toast.makeText(this@UninstallGuardService, "Защита снята. Повтори удаление.", Toast.LENGTH_LONG).show()
                    removePrompt(wm)
                } else pin.error = "Неверный PIN"
            }
        })
        panel.addView(Button(this).apply { text = "Отмена"; setOnClickListener { removePrompt(wm) } })

        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.88f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_DIM_BEHIND,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER; dimAmount = 0.72f }

        overlay = panel
        try { wm.addView(panel, params) } catch (_: Exception) { promptShown = false; overlay = null }
    }

    private fun removePrompt(wm: WindowManager? = getSystemService(WINDOW_SERVICE) as WindowManager) {
        try { overlay?.let { wm?.removeView(it) } } catch (_: Exception) { }
        overlay = null
        promptShown = false
        lastDismiss = android.os.SystemClock.uptimeMillis()
    }
    override fun onInterrupt() { removePrompt() }
    override fun onDestroy() { removePrompt(); super.onDestroy() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
